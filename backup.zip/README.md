# datastructure
> MacOS下执行C++代码:
```
clang++ -std=c++11 -stdlib=libc++ -O3 hello_world.cpp; ./a.out; rm a.out
```

